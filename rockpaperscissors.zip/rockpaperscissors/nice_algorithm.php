
<?php

    $input = isset($_GET['input']) ? $_GET['input'] : '';

    $result = '';

    if ($input != '') {
        // här kommer stensaxpåse algoritmen
        $choices = array('🤛', '✋', '✌');
        $rand = rand(0, 2);
        $user = $input;
        $computer = $choices[$rand];
    
        // nästa index i arrayn, börjar om på noll om i > count($choices)
        function winningChoice($i) {
            return ($i + 1) % 3;
        }
    
        if ($user == $choices[$rand]) $result = 'lika'; // specialfall om båda har valt samma
        else {
            // annars kollar man om spelarens val är lika med nästa item i arrayn
            if ($user == $choices[winningChoice($rand)]) $result = 'vinst';
            else {
                $result = 'förlust'; // om inte blir det en förlust för spelaren
            }
        }

    }

    $wins = 0;
    $tries = 0;
    $ties = 0;

    if (isset($_COOKIE['wins']) && is_numeric($_COOKIE['wins'])) {
        $wins = intval($_COOKIE['wins']) + ($result == 'vinst' ? 1 : 0);
    }
    
    if (isset($_COOKIE['tries']) && is_numeric($_COOKIE['tries'])) {
        $tries = intval($_COOKIE['tries']) + ($result != '' ? 1 : 0);
    }

    if (isset($_COOKIE['ties']) && is_numeric($_COOKIE['ties'])) {
        $ties = intval($_COOKIE['ties']) + ($result == 'lika' ? 1 : 0);
    }

    setcookie('tries', $tries);
    setcookie('wins', $wins);
    setcookie('ties', $ties);

    echo '';
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" type="text/css" href="style.css">
        <script defer src="index.js"></script>
        <title>🤛 ✌ ✋</title>
    </head>
    <body>
        <header>
            <h1>🤛 ✌ ✋</h1>
        </header>

        <main style="display: none;">
        <div class="content">
        <?php
            if (isset($_GET['input'])) {
                echo
                "<div class=\"results\">
                    <h2 class=\"result player\">Ditt val: $user</h2>
                    <h2 class=\"result computer\">Datorns val: $computer</h2>
                    <h2>Resultat: <span class=\"$result\">$result</span></h2>
                </div>";
            }
        ?>

        <div class="history">
            <h3>Vinster: <?= $wins . ($result == 'vinst' ? '<span class="increase vinst">+1</span>' : '') ?></h3>
            <h3>Försök: <?= $tries . ($result != '' ? '<span class="increase lika">+1</span>' : '') ?></h3>
            <h3>Lika: <?= $ties . ($result == 'lika' ? '<span class="increase lika">+1</span>' : '') ?></h3>
        </div>

        <form action="nice_algorithm.php" method="GET">

            <label class="container">
                <input type="radio" name="input" value="🤛" <?= $input == '🤛' ? 'checked="true"' : '' ?>>
                <span class="radio-button">🤛</span>
            </label>

            <label class="container">
                <input type="radio" name="input" value="✌" <?= $input == '✌' ? 'checked="true"' : '' ?>>
                <span class="radio-button">✌</span>
            </label>

            <label class="container">
                <input type="radio" name="input" value="✋" <?= $input == '✋' ? 'checked="true"' : '' ?>>
                <span class="radio-button">✋</span>
            </label>

            <input type="submit" value="KÖR">
        </form>
        </div>
        </main>
    </body>
</html>