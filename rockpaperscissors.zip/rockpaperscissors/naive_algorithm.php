
<?php
    if (isset($_GET['input'])) {
        
        $choices = array('sten', 'påse', 'sax');
        $computer = $choices[rand(0, 2)];
        $user = $_GET['input'];
        
        if ($user == $computer) $result = 'lika';
        else {
            $win = false;
            if ($user == 'sten' && $computer == 'sax') {
                $win = true;
            }
            if ($user == 'sax' && $computer == 'påse') {
                $win = true;
            }
            if ($user == 'påse' && $computer == 'sten') {
                $win = true;
            }
            $result = $win ? 'vinst' : 'förlust';
        }

        if (!isset($_COOKIE['wins']) || !is_numeric($_COOKIE['wins'])) {
            setcookie('wins', 0);
        }
        else {
            setcookie('wins', intval($_COOKIE['wins']) + ($result == 'vinst' ? 1 : 0));
        }

        if (!isset($_COOKIE['tries']) || !is_numeric($_COOKIE['tries'])) {
            setcookie('tries', 0);
        }
        else {
            setcookie('tries', intval($_COOKIE['tries']) + 1);
        }
    }

    echo '';

    $wins = $_COOKIE['wins'];
    $tries = $_COOKIE['tries'];
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Sten Sax Påse</title>
    </head>
    <body>
        <h1>Sten Sax Påse</h1>

        <?php
            echo "<h3>Vinster: $wins</h3>";
            echo "<h3>Försök: $tries</h3>";
        ?>

        <?php
            if (isset($_GET['input'])) {
                echo
                "<div>
                    <h2>Ditt val: $user</h2>
                    <h2>Datorns val: $computer</h2>
                    <h2>Resultat: $result</h2>
                </div>";
            }
        ?>

        <form action="naive_algorithm.php" method="GET">

            <input type="radio" name="input" value="sten">
            <label>Sten</label>

            <input type="radio" name="input" value="sax">
            <label>Sax</label>

            <input type="radio" name="input" value="påse">
            <label>Påse</label>

            <input type="submit">
        </form>
    </body>
</html>